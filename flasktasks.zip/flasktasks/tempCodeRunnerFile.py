from flask import Flask, render_template, request
import math

app = Flask(__name__)

# Function to calculate BMR using the Mifflin-St Jeor Equation
def calculate_bmr(weight, height, age, gender):
    if gender == 'male':
        # Mifflin-St Jeor Equation for men
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
    else:
        # Mifflin-St Jeor Equation for women
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
    return bmr

# Function to calculate Maintenance Calories based on activity level
def calculate_maintenance_calories(bmr, activity_level):
    if activity_level == 'sedentary':
        return bmr * 1.2
    elif activity_level == 'light':
        return bmr * 1.375
    elif activity_level == 'moderate':
        return bmr * 1.55
    elif activity_level == 'active':
        return bmr * 1.725
    elif activity_level == 'very_active':
        return bmr * 1.9
    return bmr

# Simple diet plan based on maintenance calories
def get_diet_plan(maintenance_calories):
    # Just an example of basic macronutrient distribution
    protein = maintenance_calories * 0.3 / 4  # 30% protein, 1g = 4 calories
    fat = maintenance_calories * 0.3 / 9      # 30% fat, 1g = 9 calories
    carbs = maintenance_calories * 0.4 / 4    # 40% carbs, 1g = 4 calories

    return {
        'protein': f"{int(protein)} grams",
        'fat': f"{int(fat)} grams",
        'carbs': f"{int(carbs)} grams"
    }

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get data from form
        weight = float(request.form['weight'])
        height = float(request.form['height'])
        age = int(request.form['age'])
        gender = request.form['gender']
        activity_level = request.form['activity_level']

        # Calculate BMR
        bmr = calculate_bmr(weight, height, age, gender)

        # Calculate maintenance calories
        maintenance_calories = calculate_maintenance_calories(bmr, activity_level)

        # Get diet plan
        diet_plan = get_diet_plan(maintenance_calories)

        return render_template('index.html', maintenance_calories=maintenance_calories,
                               diet_plan=diet_plan)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)