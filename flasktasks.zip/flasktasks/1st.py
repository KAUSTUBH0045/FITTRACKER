from flask import Flask, render_template, request
import math

app = Flask(__name__)
def calculate_factor(weight, height, age, gender):
    if gender == 'male':
        factor = 10 * weight + 6.25 * height - 5 * age + 5
    else:
        factor = 10 * weight + 6.25 * height - 5 * age - 161
    return factor
def calculate_maintenance_calories(factor, activity_level):
    if activity_level == 'sedentary':
        return factor * 1.2
    elif activity_level == 'light':
        return factor * 1.375
    elif activity_level == 'moderate':
        return factor * 1.55
    elif activity_level == 'active':
        return factor * 1.725
    elif activity_level == 'very_active':
        return factor * 1.9
    return factor
def get_diet_plan(maintenance_calories):
    protein = maintenance_calories * 0.3 / 4  
    fat = maintenance_calories * 0.3 / 9      
    carbs = maintenance_calories * 0.4 / 4    
    return {
        'protein': f"{int(protein)} grams",
        'fat': f"{int(fat)} grams",
        'carbs': f"{int(carbs)} grams"
    }
# def diet_planning(goal):
#     if goal=='Loss':
#         k=" <p>* After starting your day with cucumber water, have oats porridge and mixed nuts for breakfast.<br>"
#     else :
#         k="egistered dietitians thoughtfully create EatingWell’s meal plans to be easy-to-follow and delicious. Each meal plan meets specific parameters depending on the health condition and/or lifestyle goal it is targeting and is analyzed for accuracy using the nutrition database, ESHA Food Processor. As nutritional needs differ from person to person, we encourage you to use these plans as inspiration and adjust as you see fit."
#     print(k)
@app.route('/login')
def login():
    return render_template('login.html')
@app.route('/diet', methods=['GET', 'POST'])
def diet():
    if request.method == 'POST':
        weight = float(request.form['weight'])
        height = float(request.form['height'])
        age = int(request.form['age'])
        gender = request.form['gender']
        activity_level = request.form['activity_level']
        goal =request.form['goal']
        factor = calculate_factor(weight, height, age, gender)
        maintenance_calories = calculate_maintenance_calories(factor, activity_level)
        diet_plan = get_diet_plan(maintenance_calories)
        # lol = diet_planning(goal)

        return render_template('diet.html', maintenance_calories=maintenance_calories,
                               diet_plan=diet_plan)
    
    return render_template('diet.html')
@app.route('/1st')
def lol():
    return render_template('lol.html')
@app.route('/feedback')
def feedback():
    return render_template('feedback.html')
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/contact')
def contact():
    return render_template('contactus.html')
@app.route('/afterlogin')
def afterlogin():
    return render_template('afterlogin.html')
@app.route("/km.png")
def image():
    return render_template("km.png")


if __name__ == '__main__':
    app.run(debug=True)